import pandas as pd
import numpy as np
from sklearn.discriminant_analysis import  LinearDiscriminantAnalysis
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.naive_bayes import GaussianNB

x=pd.DataFrame()
x_applied=pd.DataFrame()

tinta="VULNERAB"
variabile=list(x.columns.values[:-1])
x_train,x_test,y_train,y_test=train_test_split(x[variabile],x[tinta],train_size=0.4)

lda=LinearDiscriminantAnalysis()
lda.fit_transform(x_train,y_train)

#sccoruri
scores_train=lda.fit_transform(x_test)
scores_test=lda.fit_transform(x_test)

#Predicția în setul de aplicare model liniar
prediction_applied=lda.predict(x_applied)
#Predictia in setul de testare model liniar
prediction_test=lda.predict(x_test)

#Trasare plot instanțe în axe discriminante
plt.figure(figsize=(8,8))
plt.xlabel("x")
plt.ylabel("y")
plt.scatter(scores_test[:,0],scores_test[:,1],c=y_test,cmap="coolwarm")
plt.show()

#Trasare plot distribuții în axele discriminante
#KDE PLOT

plt.figure(figsize=(8,8))
for cls in np.unique(y_test):
    sns.kdeplot(scores_test[y_test==cls,0])
plt.show()

#evaluare model liniar ( matricea de confuzie + acuratete)
conf_matrix=confusion_matrix(y_test,prediction_test)
print("Matricea de confuzie", conf_matrix)
print("Raport de clasificare", classification_report(y_test,prediction_test))
print("Acuratete", accuracy_score(y_test,prediction_test))

#Model Bayesian
gnb=GaussianNB()
gnb.fit(x_train,y_train)
prediction_test_gnb=gnb.predict(x_test)
prediction_applied_gnb=gnb.predict(x_applied)

#Evaluare model bayesian (matricea de confuzie + indicatori de acuratețe)

conf_matrix_gnb=confusion_matrix(y_test,prediction_test_gnb)
print("matricea de confuzie", conf_matrix_gnb)
print("raport de clasificare", classification_report(y_test,prediction_test_gnb))
print("acuratete", accuracy_score(y_test,prediction_test_gnb))





