import pandas as pd
import numpy as np

# citirea datelor brute din fisierul csv
def load_raw_data (file_path):
    try:
        df = pd.read_csv(file_path)
        return df
    except Exception as e:
        print(f"Eroare la citirea datelor: {e}")
        return None

# verificarea existentei valorilor nan si inlocuirea acestora cu media de pe fiecare coloana
def missing_values_handler(df):
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    for col in numeric_cols:
        if df[col].isnull().any():
            df[col] = df[col].fillna(df[col].mean())

    return df

# conversia lui date in obiect de tip datetime
def time_processing(df):
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df["year"] = df["date"].dt.year
    df["month"] = df["date"].dt.month
    return df

# calcularea indicatorului de punctualitate al trenurilor
def calculate_punctuality(df):
    df["punctuality_rate"] = 100 - (df["num_late_arr"] / df["num_scheduled"] * 100)
    df["punctuality_rate"] = df["punctuality_rate"].replace([np.inf, -np.inf], 100)
    return df

# salvarea datelor intr-un nou fisier csv
def save_processed_data(df, output_path = "tgv_final_processed.csv"):
    try:
        df.to_csv(output_path, index=False)
        print(f"Datele procesate au fost salvate in {output_path}.")
    except Exception as e:
        print(f"Eroare la salvarea datelor: {e}")

# apelul functiilor necesare preprocesarii datelor
def run_preprocessing_data(input_file):
    df = load_raw_data(input_file)
    if df is not None:
        df = missing_values_handler(df)
        df = time_processing(df)
        df = calculate_punctuality(df)
        save_processed_data(df)
        return df
    
if __name__ == "__main__":
    run_preprocessing_data("tgvinoui_2020_2025.csv")