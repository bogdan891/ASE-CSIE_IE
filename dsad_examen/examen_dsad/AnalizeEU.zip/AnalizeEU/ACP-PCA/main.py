import numpy as np
import pandas as pd
import seaborn as sns
from googleapiclient.mimeparse import quality
from matplotlib import pyplot as plt
from pandas.core.dtypes.common import is_numeric_dtype
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

#cerinte pentru pca de la furtuna:
# 1. Varianță componente
# 2. Plot varianță componente cu evidențierea criteriilor de relevanță
# 3. Calcul corelații factoriale (corelații variabile observate - componente)
# 4. Trasare corelogramă corelații factoriale
# 5. Trasare cercul corelațiilor
# 6. Calcul componente și/sau scoruri
# 7. Trasare plot componente/scoruri
# 8. Calcul cosinusuri
# 9. Calcul contribuții
# 10. Calcul comunalități
# 11. Trasare corelogramă comunalități

x_raw=pd.read_csv("numele fisierului")
x=StandardScaler().fit_transform(x_raw)

#inceputul
pca=PCA()
C=pca.fit_transform(x) #componente principale (scorurile PCA)

# varianta componente
alpha=pca.explained_variance_ #variatia explicata de fiecare componenta

#Plot varianta componente cu evidentierea criterilor de relevanta

plt.plot(range(1,len(alpha)+1), alpha, marker='o')
plt.xlabel("Componenta Principala")
plt.ylabel("Varianta Explicata")
plt.title("Scree Plot")
plt.show()

# Calcul corelații factoriale (corelații variabile observate - componente)
a=pca.components_.T #matricea componentelor (incarcari factoriale)
rxc=a*np.sqrt(alpha)  #incarcarile factoriale(factor loadings)


#Trasare corelogramă corelații factoriale
ax=sns.heatmap(pd.DataFrame(rxc), annot=True,cmp="coolwarm",center=0)
plt.title("Corelogarama corelatii factoriale")
plt.show()

#Trasare cercul corelațiilor
plt.figure(figsize=(6,6))
plt.axhline(0,color="gray", linewidth=0.5)
plt.axvline(0,color="gray",linewidth=0.5)
plt.scatter(rxc[:,0],rxc[:,1])
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.title("Cercul corelatiilor")

#Calcul componente și/sau scoruri

scores=C/np.sqrt(alpha) #standardizarea scorurilor

#plot pentru primele scoruri
plt.figure(figsize=(8,6))
plt.scatter(scores[:,0],scores[:1], alpha=0.7)
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.title("plot pentru primele scoruri")
plt.grid()
plt.show()

#calcul cosinusuri
C2=C*C
quality=np.transpose(C2.T/np.sum(C2,axis=1))

#calcul contributii
contributions = C2/(x.shape[0]*alpha)

#calcul comunalitati
comunalitati=np.comsum(rxc*rxc,axis=1)

#corelogarama comunalitatilor
plt.figure(figsize=(8,6))
sns.heatmap(pd.DataFrame(comunalitati), annot=True, cmap="coolwarm")
plt.title("Corelograma comunalitati")
plt.show()



