#cerinte:
# Analiza factorabilității - Bartlett
# Analiza factorabilității - KMO
# Calcul varianță factori (cu/fără rotație)
# Calcul corelații factoriale (cu/fără rotație)
# Trasare corelogramă corelații factoriale (cu/fără rotație)
# Trasare cercul corelațiilor (cu/fără rotație)
# Calcul comunalități și varianță specifică
# Trasare corelogramă comunalități și varianță specifică
# Calcul scoruri (cu/fără rotație)
# Trasare plot scoruri

import numpy as np
import pandas as pd
import seaborn as sb
import matplotlib.pyplot as plt
from factor_analyzer import FactorAnalyzer, calculate_kmo,calculate_bartlett_sphericity

x=pd.read_csv("datele mele")
efa=FactorAnalyzer(n_factors=x.shape[1]-1) # asta e fara rotatie

#bartlett test

chi_sqare_value,p_value=calculate_bartlett_sphericity(x)
print(chi_sqare_value)
print(p_value)
if p_value>0.05:
    print("nu sunt factoriale")

#kmo test
kmo=calculate_kmo(x)
print(f"KMO scores: {kmo[1]:.3f}")

efa=FactorAnalyzer(n_factors=x.shape[1]-1) # asta e fara rotatie

#Calcul varianță factori (cu rotație)
efa_varimax=FactorAnalyzer(n_factors=x.shape[1]-1,rotation="varimax")
efa_varimax.fit(x)
eigenvalues_varimax,_=efa_varimax.get_eigenvalues()


#Calcul varianță factori (fara rotație)
efa_no_rotation=FactorAnalyzer(n_factors=x.shape[1]-1,rotation=None)
efa_no_rotation.fit(x)
eigenvalues_no_rotation,_=efa_no_rotation.get_eigenvalues()


#Calcul corelații factoriale (fără rotație)
factorLoagins=efa.loadings_

#Calcul corelații factoriale (cu rotație)
factorLoagins_rotation=efa_varimax.loadings_

#Trasare corelogarama corelatii factoriale

factorLoagins_rotation_df=pd.DataFrame(factorLoagins_rotation)

plt.figure(figsize=(8,8))
sb.heatmap(factorLoagins_rotation_df,annot=True,cmap="coolwarm")
plt.title("Corelogarama corelatii factoriale CU rotatie")
plt.xlabel("Factori")
plt.ylabel("Variabile observate")
plt.show()

#Trasare cercul corelațiilor (cu/fără rotație)

plt.figure(figsize=(12, 12))
plt.title('Correlation circle')
T = [t for t in np.arange(0, np.pi*2, 0.01)]
X = [np.cos(t) for t in T]
Y = [np.sin(t) for t in T]
plt.plot(X, Y)
plt.axhline(0, c='g')
plt.axvline(0, c='g')
plt.scatter(factorLoagins[:, 0], factorLoagins[:, 1])
plt.grid()
plt.show()

#Calcul comunalitati si varianta specifica

comunalitati=efa.get_communalities()
specificFactors=efa.get_uniquenesses()

#trasare corelograma comunalitati si varianta specifica

plt.figure(figsize=(8,8))
sb.heatmap(pd.DataFrame({"Comunalitati ": comunalitati,"Varianta specifica" :specificFactors}),annot=True,cmap="coolwarm")
plt.title("Corelograma comunalitati si varianta specifica")
plt.show()


#Calcul scoruri (cu/fără rotație)
scores=efa.fit_transform(x)

#trasare plot scoruri
plt.figure(figsize=(8,8))
plt.scatter(scores[:,0],scores[:,1],alpha=0.7)
plt.xlabel("Factor 1")
plt.ylabel("Fcator 2")
plt.title("Rep obs pe primele 2 factori")
plt.grid()
plt.show()




