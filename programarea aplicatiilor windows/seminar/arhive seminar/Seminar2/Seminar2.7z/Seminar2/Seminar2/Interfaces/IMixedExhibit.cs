﻿namespace Seminar2.Interfaces
{
    public interface IMixedExhibit : ITerrestrialExhibit, IAquaticExhibit
    {
    }
}
