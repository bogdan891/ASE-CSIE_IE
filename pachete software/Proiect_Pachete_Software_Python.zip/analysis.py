import numpy as np
import statsmodels.api as sm
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.cluster import KMeans
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

# Codificarea datelor
def encode_categorical_data(df):
    df_ml = df.copy()
    le = LabelEncoder()

    if "service" in df_ml.columns:
        df_ml["service_encoded"] = le.fit_transform(df_ml["service"].astype(str))

    return df_ml

# scalare + clusterizare k-means
def perform_clustering(df):
    station_stats = df.groupby("dep_station").agg({
        "num_scheduled": "sum",
        "punctuality_rate": "mean"
    }).reset_index().dropna()

    scaler = StandardScaler()
    scaled_features = scaler.fit_transform(station_stats[["num_scheduled", "punctuality_rate"]])

    kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
    station_stats["Cluster"] = kmeans.fit_predict(scaled_features)

    cluster_means = station_stats.groupby("Cluster")["punctuality_rate"].mean().sort_values()

    cluster_labels = {
        cluster_means.index[0] : "Operational Risk (Low punctuality)",
        cluster_means.index[1] : "Medium Performance",
        cluster_means.index[2] : "Maximum Efficiency (High Punctuality)"
    }
    station_stats["Station_Profile"] = station_stats["Cluster"].map(cluster_labels)

    return station_stats

# Regresie logistica
def run_logistic_regression(df):
    df_log = df.dropna(subset=["num_scheduled", "punctuality_rate"]).copy()
    df_log["Risk_Flag"] = np.where(df_log["punctuality_rate"] < 90, 1, 0)

    X = df_log[["num_scheduled"]]
    Y = df_log["Risk_Flag"]

    X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=42)

    model = LogisticRegression()
    model.fit(X_train, Y_train)

    accuracy = model.score(X_test, Y_test)

    return accuracy, model

# Regresie multipla
def run_multiple_regression(df):
    colls_needed = ["avg_delay_all_dep", "num_scheduled"]

    available_cols = [col for col in colls_needed if col in df.columns]

    df_reg = df.dropna(subset=available_cols).copy()

    target_col = "avg_delay_all_dep" if "avg_delay_all_dep" in df_reg.columns else "punctuality_rate"

    Y = df_reg[target_col]

    x_cols = [col for col in ["num_scheduled", "delay_cause_infrastructure", "delay_cause_external"] if col in df_reg.columns]
    X = df_reg[x_cols]

    X = sm.add_constant(X)

    model = sm.OLS(Y, X).fit()

    return model