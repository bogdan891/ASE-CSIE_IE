﻿namespace Seminar2.Interfaces
{
    public interface IAquaticExhibit
    {
        bool HasFreshWater { get; set; }
    }
}
