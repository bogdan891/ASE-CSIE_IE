import streamlit as st
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
import plotly.express as px
from shapely.geometry import Point

def plot_punctualitate_in_timp(df):
    """Generează un grafic de tip linie cu evoluția punctualității"""
    trend_df = df.groupby('date')['punctuality_rate'].mean().reset_index()
    fig = px.line(trend_df, x='date', y='punctuality_rate',
                  title='Evoluția Ratei Medii de Punctualitate în Timp',
                  labels={'date': 'Data (An-Lună)', 'punctuality_rate': 'Punctualitate (%)'},
                  markers=True)
    fig.update_yaxes(range=[60, 100])
    return fig

def plot_cauze_intarzieri(df):
    """Generează un grafic tip plăcintă pentru cauzele întârzierilor"""
    cause_cols = ['delay_cause_external', 'delay_cause_infrastructure',
                  'delay_cause_traffic', 'delay_cause_rolling_stock',
                  'delay_cause_station', 'delay_cause_passenger']

    causes_mean = df[cause_cols].mean().reset_index()
    causes_mean.columns = ['Cauza', 'Procentaj Mediu']

    nume_frumoase = {
        'delay_cause_external': 'Cauze Externe (Vreme, etc.)',
        'delay_cause_infrastructure': 'Infrastructură',
        'delay_cause_traffic': 'Management Trafic',
        'delay_cause_rolling_stock': 'Material Rulant (Locomotive)',
        'delay_cause_station': 'Management în Gară',
        'delay_cause_passenger': 'Pasageri (Afluență, urcare)'
    }
    causes_mean['Cauza'] = causes_mean['Cauza'].map(nume_frumoase)

    fig = px.pie(causes_mean, values='Procentaj Mediu', names='Cauza',
                 title='Distribuția Cauzelor de Întârziere', hole=0.4)
    return fig

def harta_geopandas(df):
    """Generează o hartă statică Geopandas cu principalele gări"""
    coords = {
        'PARIS MONTPARNASSE': (48.841, 2.318),
        'PARIS LYON': (48.844, 2.374),
        'LYON PART DIEU': (45.760, 4.859),
        'MARSEILLE ST CHARLES': (43.302, 5.380),
        'BORDEAUX ST JEAN': (44.825, -0.555),
        'LILLE EUROPE': (50.639, 3.075),
        'STRASBOURG': (48.585, 7.734)
    }

    df_map = df[df['dep_station'].isin(coords.keys())].copy()
    station_stats = df_map.groupby('dep_station')['num_scheduled'].sum().reset_index()

    station_stats['lat'] = station_stats['dep_station'].map(lambda x: coords[x][0])
    station_stats['lon'] = station_stats['dep_station'].map(lambda x: coords[x][1])

    fig = px.scatter_mapbox(
        station_stats,
        lat="lat",
        lon="lon",
        hover_name="dep_station",
        hover_data={"lat": False, "lon": False, "num_scheduled": True},
        size="num_scheduled", # marimea punctului variaza dupa nr de trenuri
        color_discrete_sequence=["crimson"],
        zoom=4.5,
        center={"lat": 46.2276, "lon": 2.2137},
        title="Harta Interactivă a Traficului TGV (Zoom & Pan)",
        mapbox_style="carto-positron"
    )

    fig.update_layout(margin={"r": 0, "t": 40, "l": 0, "b": 0})

    return fig