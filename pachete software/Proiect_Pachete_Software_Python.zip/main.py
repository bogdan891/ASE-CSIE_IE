import streamlit as st
import pandas as pd
import time
import matplotlib.pyplot as plt
from visualizations import plot_punctualitate_in_timp, plot_cauze_intarzieri, harta_geopandas
from analysis import perform_clustering, run_logistic_regression, run_multiple_regression

st.title("Evaluarea performanței TGV sub presiunea traficului")
st.markdown("""
#### Analiza corelației dintre volumul de trenuri și punctualitate în contextul deschiderii pieței (2020-2025)
""")
st.markdown("---")

@st.cache_data
def load_data():
    df = pd.read_csv("tgv_final_processed.csv")
    return df

try:
    df = load_data()

    st.sidebar.header("Filtrează datele")

    toti_anii = sorted(df['year'].dropna().unique())
    an_selectat = st.sidebar.selectbox("Alege un an:", toti_anii)

    toate_serviciile = ["Toate"] + list(df['service'].dropna().unique())
    serviciu_selectat = st.sidebar.selectbox("Alege tipul de serviciu:", toate_serviciile)

    df_filtrat = df[df['year'] == an_selectat]
    if serviciu_selectat != "Toate":
        df_filtrat = df_filtrat[df_filtrat['service'] == serviciu_selectat]

    tab1, tab2, tab3 = st.tabs(["Indicatori și Date", "Vizualizări geografice", "Machine Learning"])

    with tab1:
        st.subheader(f"Indicatori generali - Anul {int(an_selectat)}")
        col1, col2, col3 = st.columns(3)

        col1.metric("Total trenuri programate", f"{df_filtrat['num_scheduled'].sum():,.0f}")
        col2.metric("Total trenuri anulate", f"{df_filtrat['num_cancelled'].sum():,.0f}")
        if 'punctuality_rate' in df_filtrat.columns:
            rata_medie = df_filtrat['punctuality_rate'].mean()
            col3.metric("Rata medie de punctualitate", f"{rata_medie:.2f}%")

        st.dataframe(df_filtrat.head(500), use_container_width=True)
        st.markdown("---")
        st.markdown("### Statistici descriptive")
        coloane_statistici = ['num_scheduled', 'num_cancelled', 'punctuality_rate']
        statistici = df_filtrat[coloane_statistici].describe()
        statistici = statistici.loc[['count','mean','std','min','max']]
        st.dataframe(statistici.rename(
            index={'count':'Număr înregistrări','mean':'Media','std':'Deviația standard','min':'Minimul','max':'Maximul'},
            columns={'num_scheduled': 'Trenuri programate', 'num_cancelled': 'Trenuri anulate', 'punctuality_rate': 'Punctualitate (%)'}
        ).style.background_gradient(cmap='Pastel2_r'), use_container_width=True)

    with tab2:
        col_grafic1, col_grafic2 = st.columns(2)

        with col_grafic1:
            st.plotly_chart(plot_punctualitate_in_timp(df), use_container_width=True)
            st.info(
                "**Observație:** Acest grafic urmărește fluctuațiile punctualității de-a lungul timpului. Căderile bruște ale liniei indică luni cu perturbări majore (ex. greve, condiții meteo extreme sau lucrări masive pe rețea).")

        with col_grafic2:
            st.plotly_chart(plot_cauze_intarzieri(df_filtrat), use_container_width=True)
            st.info(
                "**Observație:** Un procentaj mare la cauze externe arată o vulnerabilitate la vreme/incidente, în timp ce problemele de infrastructură indică nevoia de investiții interne.")

        st.markdown("---")
        st.subheader("Harta nodurilor feroviare")
        st.plotly_chart(harta_geopandas(df_filtrat), use_container_width=True)
        st.info(
            "**Cum se citește harta:** Mărimea punctului roșu depinde de numărul de trenuri programate. Punctele cele mai mari indică nodurile feroviare care suportă cea mai mare presiune a traficului și care, în contextul deschiderii pieței, necesită prioritizare pentru mentenanță.")

    with tab3:
        st.header("Machine Learning & Predicții")
        if st.button("Antrenează modelele ML"):
            with st.spinner("Se antrenează modelul..."):
                time.sleep(3)
                st.markdown("---")
                st.subheader("1. Segmentarea gărilor (K-Means Clustering)")
                st.markdown(
                    "Algoritmul împarte automat gările în 3 categorii de performanță pe baza volumului de trafic și al punctualității.")

                df_clusters = perform_clustering(df_filtrat)

                fig_cluster, ax = plt.subplots(figsize=(8, 6))

                culori = {
                    "Maximum Efficiency (High Punctuality)": "green",
                    "Medium Performance": "orange",
                    "Operational Risk (Low punctuality)": "red"
                }

                for profil, culoare in culori.items():
                    subset = df_clusters[df_clusters['Station_Profile'] == profil]
                    ax.scatter(subset['num_scheduled'], subset['punctuality_rate'],
                               c=culoare, label=profil, s=100, alpha=0.7, edgecolors='black')

                plt.title("Gările grupate: Performanță VS Trafic")
                plt.xlabel("Volum trenuri programate")
                plt.ylabel("Punctualitate (%)")
                plt.legend()
                plt.grid(True, linestyle='-', alpha=0.7)
                plt.tight_layout()

                st.pyplot(fig_cluster)
                st.info(
                    "**Interpretare economică:** Gările din zona roșie (Operational Risk) sunt nodurile critice. Ele au trafic mare, dar nu pot menține punctualitatea. Aici trebuie direcționate fondurile de extindere și modernizare a infrastructurii.")

                col_ml_1, col_ml_2 = st.columns(2)

                with col_ml_1:
                    st.subheader("2. Predicția riscului folosind Regresia Logistică")
                    accuracy, log_model = run_logistic_regression(df_filtrat)
                    st.metric("Acuratețea modelului", f"{accuracy * 100:.2f}%")
                    st.markdown(
                        f"Modelul Scikit-Learn prezice cu o acuratețe de **{accuracy * 100:.2f}%** dacă o rută va avea o punctualitate critică (sub 90%) analizând doar numărul de trenuri programate.")
                    st.success(
                        "Astfel putem ști în avans dacă adăugarea unor noi rute (liberalizarea pieței) va bloca sau nu rețeaua feroviară actuală.")

                with col_ml_2:
                    st.subheader("3. Impactul factorilor folosind Regresia Multiplă")
                    multi_model = run_multiple_regression(df_filtrat)
                    st.markdown("**Care este impactul fiecărui factor asupra întârzierilor la sosire?**")
                    rezultate = multi_model.params.drop('const')
                    st.dataframe(rezultate.rename("Efect (Minute/Factor)"), use_container_width=True)
                    st.warning(
                        "Coeficienții din tabel ne arată cine este 'vinovatul' principal pentru minutele de întârziere (ex: infrastructura vs. cauze externe), ghidând deciziile de bugetare ale SNCF.")

except FileNotFoundError:
    st.error("Eroare: Fișierul nu a fost găsit.")