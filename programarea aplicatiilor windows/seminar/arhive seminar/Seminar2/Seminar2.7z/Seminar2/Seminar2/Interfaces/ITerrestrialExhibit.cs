﻿namespace Seminar2.Interfaces
{
    public interface ITerrestrialExhibit
    {
        bool HasGrass { get; set; }
    }
}
